package StepDefinitions;

//import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.CustomerLogin;
import PageObjects.CustomerObjects;
import io.cucumber.java.After;
//import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import org.junit.Assert;


public class CustomerSteps 
{

	WebDriver driver=new ChromeDriver();
	CustomerObjects custobj=new CustomerObjects(driver);
	CustomerLogin custlog=new CustomerLogin(driver);
	
/*	@Before
	public void BrowserSetup() throws InterruptedException
	{
		driver.get("https://phptravels.net/login");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
	}*/
	
	@After
	public void TearDown()
	{
		driver.close();
		driver.quit();
	}
	
	@Given("user is on customer login page")
	public void user_is_on_customer_login_page() throws InterruptedException 
	{
		driver.get("https://phptravels.net/login");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		System.out.println("The loaded site: "+driver.getCurrentUrl());
	}

	@When("User enters email as {string} and password as {string}")
	public void user_enters_email_as_and_password_as(String username, String password) 
	{
		custlog.setUserName(username);
		custlog.setPassword(password);

	    
	}

	@When("user click on login button")
	public void user_click_on_login_button() throws InterruptedException
	{
		Thread.sleep(2000);
		custlog.clickLogin();
		Thread.sleep(2000);
	}

	@Then("user navigated to home page")
	public void user_navigated_to_home_page()
	{
		Assert.assertEquals("Dashboard - PHPTRAVELS",driver.getTitle());
	}

	@When("user clicks on My Bookings link")
	public void user_clicks_on_my_bookings_link() throws InterruptedException 
	{
	    Thread.sleep(2000);
		custobj.clickBooking();
	}

	@Then("user navigates to My Bookins page")
	public void user_navigates_to_my_bookins_page() 
	{
		Assert.assertEquals("Bookings - PHPTRAVELS",driver.getTitle());
	}
	
	@When("user clicks on Add Funds link")
	public void user_clicks_on_add_funds_link() throws InterruptedException
	{
		 Thread.sleep(2000);
		 custobj.clickAddFunds();
	}

	@Then("user navigates to Add Funds page")
	public void user_navigates_to_add_funds_page()
	{
		Assert.assertEquals("Add Funds - PHPTRAVELS",driver.getTitle());
	}

	@When("user clicks on My Profile link")
	public void user_clicks_on_my_profile_link() throws InterruptedException 
	{
		 Thread.sleep(2000);
		 custobj.clickMyProfile();
		 
	}

	@Then("user navigates to customer Profile Information page")
	public void user_navigates_to_customer_profile_information_page()
	{
		Assert.assertEquals("Profile - PHPTRAVELS",driver.getTitle());
	}
	
	@When("user clicks on Logout link")
	public void user_clicks_on_logout_link() throws InterruptedException 
	{
		 Thread.sleep(2000);
		 custobj.clickLogout();
		
	}

	@Then("user navigates to Login screen")
	public void user_navigates_to_login_screen() 
	{
		Assert.assertEquals("Login - PHPTRAVELS",driver.getTitle());
	}
	
	@When("user clicks on paypal radio button")
	public void user_clicks_on_paypal_radio_button() throws InterruptedException 
	{
		 Thread.sleep(2000);
		 custobj.clickPayPal();
	}

	@And("click on Pay Now button")
	public void click_on_pay_now_button() throws InterruptedException
	{
		
		custobj.clickPayNow();
		Thread.sleep(2000);
	}

	@Then("click on Back to Invoice and click Yes")
	public void click_on_back_to_invoice_and_click_yes() throws InterruptedException
	{
		Thread.sleep(2000);
	    custobj.clickBackToInvoice();
	    Thread.sleep(2000);
	    custobj.clickYes();
	}
	
	@When("user click on View Voucher link")
	public void user_click_on_view_voucher_link() throws InterruptedException 
	{
		Thread.sleep(2000);
		custobj.clickViewVoucher();
	}

	@Then("user navigates to Booking Invoice page")
	public void user_navigates_to_booking_invoice_page() 
	{
		Assert.assertEquals("Bookings - PHPTRAVELS",driver.getTitle());
	}

	@When("user update the address as {string}")
	public void user_update_the_address_as(String newAddress) 
	{
	    custobj.setAddress(newAddress);
	    
	}

	@When("click on Update Profile button")
	public void click_on_update_profile_button() throws InterruptedException
	{
		Thread.sleep(2000);
	    custobj.clickUpdateProfile();
	    
	}

	@Then("user should get a message like {string}")
	public void user_should_get_a_message_like(String message) throws InterruptedException
	{

		Thread.sleep(2000);
		boolean text=custobj.getUpdateProfileText();
		Assert.assertTrue(text);
	}
	
	
	
	
}
