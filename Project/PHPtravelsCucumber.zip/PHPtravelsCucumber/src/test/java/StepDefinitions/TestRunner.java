package StepDefinitions;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions
(
		features={ "src/test/resources/Features/CustomerLogin.feature",
				 "src/test/resources/Features/Customer.feature",
				 
				 "src/test/resources/Features/AgentLogin.feature",
				 "src/test/resources/Features/Agent.feature",
				 
				 "src/test/resources/Features/AdminLogin.feature",
				 "src/test/resources/Features/Admin.feature",
				 
				 "src/test/resources/Features/SupplierLogin.feature",
				 "src/test/resources/Features/Supplier.feature"

				},
		
		glue= "StepDefinitions", 
		//dryRun=false,
		//it will cross check whether each feature file steps having steps in step definition or not 
		monochrome=true,
		//remove unnecessary characters in console window
		plugin={"pretty",
				"html:target/HtmlReports",
				"json:target/jsonReport/reports.json",
		        "junit:target/junitReport/report.xml"
				}
)

public class TestRunner 
{

}
