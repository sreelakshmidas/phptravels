package StepDefinitions;

//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.CustomerLogin;
import io.cucumber.java.After;
//import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import org.junit.Assert;

public class CustomerLoginSteps {

	
	
	WebDriver driver=new ChromeDriver();
	CustomerLogin custlog=new CustomerLogin(driver);
	
	
	
/*	@Before
	public void BrowserSetup() throws InterruptedException
	{
		driver.get("https://phptravels.net/login");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
	}*/
	
	@After
	public void TearDown()
	{
		driver.close();
		driver.quit();
	}
	
	
	
	@Given("user is on login page")
	public void user_is_on_login_page() throws InterruptedException 
	{
		driver.get("https://phptravels.net/login");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		System.out.println("The loaded site: "+driver.getCurrentUrl());
		
	}
	@When("^user enters email as (.*) and password as (.*)$")
	public void user_enters_username_and_password(String username, String password) throws InterruptedException 
	{
		custlog.setUserName(username);
		custlog.setPassword(password);
		Thread.sleep(2000);

	}
	@And("click on login button")
	public void click_on_login_button() throws InterruptedException 
	{
		Thread.sleep(2000);
		custlog.clickLogin();
		Thread.sleep(2000);
		
	}
/*	@And("user is navigated to dashboard page")
	public void user_is_navigated_to_dashboard_page() 
	{
		//String dash=custlog.CustomerDashboard();

		Assert.assertEquals("Dashboard - PHPTRAVELS",driver.getTitle());
		driver.close();
	
			
	}*/
	@Then("User navigated to home page")
	public void user_navigated_to_home_page() 
	{
		if(driver.getPageSource().contains("Dashboard - PHPTRAVELS"))
		{
			Assert.assertTrue(true);
		
		}
		else if(driver.getPageSource().contains("Login - PHPTRAVELS"))
		{
			Assert.assertTrue(true);
			
		}
	}	
		

	
/*	@Then("user click on logout")
	public void user_click_on_logout() throws InterruptedException 
	{
		
		custlog.clickLogout();
		Thread.sleep(3000);
		//Assert.assertEquals("Login - PHPTRAVELS",driver.getTitle());
	}
*/
}
