package StepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import PageObjects.AgentObjects;

import io.cucumber.java.After;
import io.cucumber.java.en.*;

public class AgentSteps
{
	WebDriver driver=new ChromeDriver();
	AgentObjects agentObj=new AgentObjects(driver);

	@After
	public void TearDown()
	{

		driver.quit();
	}
	
	
	@Given("agent is on login page screen")
	public void agent_is_on_login_page_screen() throws InterruptedException 
	{
		driver.get("https://phptravels.net/login");
		driver.manage().window().maximize();
		Thread.sleep(2000);

		System.out.println("The loaded site: "+driver.getCurrentUrl());

		
		
	}

	@When("agent enters valid email as {string} and password as {string}")
	public void agent_enters_valid_email_as_and_password_as(String email, String pass)
	{
	    agentObj.setEmailField(email);
	    agentObj.setPasswordField(pass);
	    
	}

	@When("agent clicks on login button")
	public void agent_clicks_on_login_button() throws InterruptedException
	{
	    
		Thread.sleep(2000);
		agentObj.clickLoginButtonAgent();
		
	}

	@Then("agent navigated to home page.")
	public void agent_navigated_to_home_page() throws InterruptedException 
	{
		Thread.sleep(2000);
		Assert.assertEquals("Dashboard - PHPTRAVELS",driver.getTitle());
	}

	
	/////////////////////////////////////////////////////////////////////
	
	
	@When("agent clicks on My Bookings link then agent navigates to My Bookins page")
	public void agent_clicks_on_my_bookings_link_then_agent_navigates_to_my_bookins_page() throws InterruptedException 
	{
		Thread.sleep(2000);
		agentObj.clickBooking();
		Assert.assertEquals("Bookings - PHPTRAVELS",driver.getTitle());
	}
	
	@And("agent clicks on Add Funds link then agent navigates to Add Funds page")
	public void agent_clicks_on_add_funds_link_then_agent_navigates_to_add_funds_page() throws InterruptedException
	{
		Thread.sleep(2000);
		agentObj.clickAddFunds();
		Assert.assertEquals("Add Funds - PHPTRAVELS",driver.getTitle());
		
	}

	@And("agent clicks on My Profile link then agent navigates to agent Profile Information page")
	public void agent_clicks_on_my_profile_link_then_agent_navigates_to_agent_profile_information_page() throws InterruptedException
	{
		Thread.sleep(2000);
		agentObj.clickMyProfile();
		Assert.assertEquals("Profile - PHPTRAVELS",driver.getTitle());
	}

	@And("agent clicks on Logout link")
	public void agent_clicks_on_logout_link() throws InterruptedException
	{
		Thread.sleep(2000);
		agentObj.clickLogout();
	}

	@Then("agent navigates to Login screen")
	public void agent_navigates_to_login_screen()
	{
		Assert.assertEquals("Login - PHPTRAVELS",driver.getTitle());
		
	}

	//////////////////////////////////////////////////////////////////
	
	
	@When("user clicks on Home link it navigates user to Home Page")
	public void user_clicks_on_home_link_it_navigates_user_to_home_page() throws InterruptedException 
	{
		Thread.sleep(2000);
		agentObj.click_HomeLogo();
		Assert.assertEquals("PHPTRAVELS | Travel Technology Partner - PHPTRAVELS",driver.getTitle());
		
	}

	@And("user clicks on Hotels link it navigates to a new page,which shows about Featured Hotels details and also we can search for a hotel.")
	public void user_clicks_on_hotels_link_it_navigates_to_a_new_page_which_shows_about_featured_hotels_details_and_also_we_can_search_for_a_hotel() throws InterruptedException 
	{
		Thread.sleep(2000);
		agentObj.click_Hotel();
		Assert.assertEquals("Search Hotels - PHPTRAVELS",driver.getTitle());
	}

	@And("user clicks on Flights link it navigates to a new page,which shows about the top flight destinations and flight searching facility.")
	public void user_clicks_on_flights_link_it_navigates_to_a_new_page_which_shows_about_the_top_flight_destinations_and_flight_searching_facility() throws InterruptedException
	{
		Thread.sleep(2000);
		agentObj.click_Flights();
		Assert.assertEquals("Search flights - PHPTRAVELS",driver.getTitle());
		
	}

	@And("user clicks on Tours link it navigates to new page,which shows about the details of tour packages.")
	public void user_clicks_on_tours_link_it_navigates_to_new_page_which_shows_about_the_details_of_tour_packages() throws InterruptedException
	{
		Thread.sleep(2000);
		agentObj.click_Tours();
		Assert.assertEquals("Search Tours - PHPTRAVELS",driver.getTitle());
		
	}

	@And("user clicks on Visa link it navigates to a Visa submission page.")
	public void user_clicks_on_visa_link_it_navigates_to_a_visa_submission_page() throws InterruptedException
	{
		Thread.sleep(2000);
		agentObj.click_Visa();
		Assert.assertEquals("Submit Visa - PHPTRAVELS",driver.getTitle());
	}

	@And("user clicks on Blog link it navigates to a Blog page about tour places.")
	public void user_clicks_on_blog_link_it_navigates_to_a_blog_page_about_tour_places() throws InterruptedException 
	{
		Thread.sleep(2000);
		agentObj.click_Blog();
		Assert.assertEquals("Blog - PHPTRAVELS",driver.getTitle());
	}

	@And("finally user clicks on Offers link it navigates a new page,which shows about the offers list provided by PHPtravels.")
	public void finally_user_clicks_on_offers_link_it_navigates_a_new_page_which_shows_about_the_offers_list_provided_by_ph_ptravels() throws InterruptedException
	{
		Thread.sleep(2000);
		agentObj.click_Offers();
		Assert.assertEquals("Offers - PHPTRAVELS",driver.getTitle());
		
	}

	@Then("concluded that all links are working well.")
	public void concluded_that_all_links_are_working_well()
	{
	    System.out.println("All links are clickable and re-directing to a new page.");
		
	}

////////////////////////////////////////////////////////////////////////////
	
	@When("agent type a city name on search bar as {string} and click search button")
	public void agent_type_a_city_name_on_search_bar_as_and_click_search_button(String city) throws InterruptedException
	{
		Thread.sleep(2000);
		agentObj.search_hotel(city);
		
		
	}

	@Then("agent get a list of hotels in dubai.")
	public void agent_get_a_list_of_hotels_in_dubai()
	{
		Assert.assertEquals("Hotels in dubai - PHPTRAVELS",driver.getTitle());
		
	}


	///////////////////////////////////////////////////////////////////////////////
	
	@When("agent lick on USD drop down menu and select INR")
	public void agent_lick_on_usd_drop_down_menu_and_select_inr() throws InterruptedException 
	{
		Thread.sleep(2000);
		agentObj.select_currency();
		
		
	}

	@Then("agent should see the selected currency version is INR")
	public void agent_should_see_the_selected_currency_version_is_inr()
	{
	    
		System.out.println("INR currency version is selected");
	}

	
	
	
	
	
	
	
	
}