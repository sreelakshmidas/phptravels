package StepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.AdminLoginObjects;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.*;

public class AdminLoginSteps 
{
	WebDriver driver=new ChromeDriver();
	AdminLoginObjects adminLogin=new AdminLoginObjects(driver);
	
	
	
/*	@Before
	public void BrowserSetup() throws InterruptedException
	{
		driver.get("https://phptravels.net/admin");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
	}*/
	
	@After
	public void TearDown()
	{
		
		driver.quit();
	}
	
	
	
	@Given("admin is on login page")
	public void admin_is_on_login_page() throws InterruptedException
	{
		driver.get("https://phptravels.net/admin");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		System.out.println("The loaded site: "+driver.getCurrentUrl());
	}

	@When("^admin enters email as (.*) and password as (.*)$")
	public void admin_enters_username_and_password(String email, String password) throws InterruptedException
	{
	    adminLogin.setEmail(email);
	    adminLogin.setPassword(password);
	    Thread.sleep(2000);
	}

	@And("admin click on login button")
	public void admin_click_on_login_button() throws InterruptedException
	{
	
		adminLogin.clickLoginButton();
		Thread.sleep(2000);
		
	}

	@Then("admin navigated to home page")
	public void admin_navigated_to_home_page() 
	{
		if(driver.getPageSource().contains("Dashboard"))
		{
			Assert.assertTrue(true);
		
		}
		else if(driver.getPageSource().contains("Administator Login"))
		{
			Assert.assertTrue(true);
			
		}
	}

	
}
