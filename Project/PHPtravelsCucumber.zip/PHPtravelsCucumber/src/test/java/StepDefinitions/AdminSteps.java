package StepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.AdminObjects;
import io.cucumber.java.After;
import io.cucumber.java.en.*;

public class AdminSteps
{

	WebDriver driver=new ChromeDriver();
	AdminObjects adminObj=new AdminObjects(driver);
	
	
	
	@After
	public void TearDown()
	{
	
		driver.quit();
	}
	
	
	
	@Given("admin is on login page screen")
	public void admin_is_on_login_page_screen() throws InterruptedException
	{
		driver.get("https://phptravels.net/admin");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		System.out.println("The loaded site: "+driver.getCurrentUrl());
	}

	@When("admin enters valid email as {string} and password as {string}")
	public void admin_enters_valid_email_as_and_password_as(String mail, String pass) 
	{
	   adminObj.setEmail(mail);
	   adminObj.setPassword(pass);
		
	}

	@And("admin clicks on login button")
	public void admin_clicks_on_login_button() throws InterruptedException
	{
	    
		Thread.sleep(2000);
		adminObj.clickLoginButton();
	
	}

	@Then("admin navigated to home page.")
	public void admin_navigated_to_home_page() throws InterruptedException
	{
		Thread.sleep(2000);
	//	driver.switchTo().alert().accept();
		Assert.assertEquals("Dashboard",driver.getTitle());
		
	}

	@When("admin click on Bookings link, then system navigates to admin Bookings page")
	public void admin_click_on_bookings_link_then_system_navigates_to_admin_bookings_page() throws InterruptedException
	{
	    adminObj.clickAdminBookings();
	    Thread.sleep(2000);
	//	driver.switchTo().alert().accept();
		Assert.assertEquals("All Bookings View",driver.getTitle());
		
	}

	@And("admin click on INVOICE where it is Payment Status is PAID")
	public void admin_click_on_invoice_where_it_is_payment_status_is_paid() throws InterruptedException
	{
		Thread.sleep(2000);
		adminObj.setPaid();
		
	}

	@Then("admin can see the Booking Invoice")
	public void admin_can_see_the_booking_invoice() 
	{
		//driver.switchTo().alert().accept();
		Assert.assertEquals("All Bookings View",driver.getTitle());
		
	}

	
	@And("admin select a record having Booking Status as Cancelled and click on that cross mark for deletion.")
	public void admin_select_a_record_having_booking_status_as_cancelled_and_click_on_that_cross_mark_for_deletion() 
	{
	    adminObj.delete_invoice_button();
	 
		
	}

	@Then("system pop up a confirmation message for ensuring deletion, then click Ok.")
	public void system_pop_up_a_confirmation_message_for_ensuring_deletion_then_click_ok()
	{
	   
		   driver.switchTo().alert().accept();
		    
	}

	@And("admin select a record having Booking Status Pending and change into Confirmed")
	public void admin_select_a_record_having_booking_status_pending_and_change_into_confirmed() 
	{
	    adminObj.select_confirm();
		
	}

	@Then("check the Confirmed Booking count is increased or not.")
	public void check_the_confirmed_booking_count_is_increased_or_not()
	{
	    
		System.out.println("Confirmed book count is increased");
		
	}

	@When("admin click on Website link")
	public void admin_click_on_website_link() throws InterruptedException
	{
	    adminObj.click_website();
	    Thread.sleep(2000);
	    
	}

	@Then("system navigates to a different page")
	public void system_navigates_to_a_different_page()
	{
	    
		Assert.assertEquals("Dashboard",driver.getTitle());
	}


	
	
	
}
