package StepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.AdminObjects;
import PageObjects.SupplierObjects;
import io.cucumber.java.After;
import io.cucumber.java.en.*;

public class SupplierSteps
{
	WebDriver driver=new ChromeDriver();
	SupplierObjects supplierObj=new SupplierObjects(driver);

	@After
	public void TearDown()
	{

		driver.quit();
	}



	@Given("supplier is on login page screen")
	public void supplier_is_on_login_page_screen() throws InterruptedException 
	{
		driver.get("https://phptravels.net/supplier");
		driver.manage().window().maximize();
		Thread.sleep(2000);

		System.out.println("The loaded site: "+driver.getCurrentUrl());

	}

	@When("supplier enters valid email as {string} and password as {string}")
	public void supplier_enters_valid_email_as_and_password_as(String email, String password) 
	{
		supplierObj.setEmail(email);
		supplierObj.setPassword(password);


	}

	@And("supplier clicks on login button")
	public void supplier_clicks_on_login_button() throws InterruptedException
	{
		Thread.sleep(2000);
		supplierObj.clickLoginButton();

	}

	@Then("supplier navigated to home page.")
	public void supplier_navigated_to_home_page() throws InterruptedException
	{
		Thread.sleep(2000);
	//	driver.switchTo().alert().accept();
		Assert.assertEquals("Dashboard",driver.getTitle());
		
	}
	
	@When("supplier entered to the dashboard page")
	public void supplier_entered_to_the_dashboard_page()
	{
	    
		Assert.assertEquals("Dashboard",driver.getTitle());
	}

	@Then("check whether the required text {string} is present or not")
	public void check_whether_the_required_text_is_present_or_not(String text) throws InterruptedException 
	{
		Thread.sleep(2000);
		boolean reqText=supplierObj.getRequiredText();
		Assert.assertTrue(reqText);
		
	}
	
	@Then("supplier check whether the required text {string} is present or not")
	public void supplier_check_whether_the_required_text_is_present_or_not(String revenue) throws InterruptedException 
	{
		Thread.sleep(2000);
		boolean revenueText=supplierObj.getRevenueText();
		Assert.assertTrue(revenueText);
		
	}
	
	@When("supplier click on Bookings link, then system navigates to admin Bookings page")
	public void supplier_click_on_bookings_link_then_system_navigates_to_admin_bookings_page() 
	{
	    
		supplierObj.clickSupplierBookings();
		
		
	}

	@Then("supplier select a record having Booking Status Pending and change into Confirmed and check whether the Confirmed Booking count is increased or not.")
	public void supplier_select_a_record_having_booking_status_pending_and_change_into_confirmed_and_check_whether_the_confirmed_booking_count_is_increased_or_not()
	{
	 
		Assert.assertEquals("All Bookings View",driver.getTitle());
		
	}	
	
	@When("supplier clicks on Tours link")
	public void supplier_clicks_on_tours_link() throws InterruptedException 
	{
	    
		supplierObj.clickSupplierTours();
		Thread.sleep(2000);
		
	}

	@Then("it navigated to a new page about tours options")
	public void it_navigated_to_a_new_page_about_tours_options() throws InterruptedException
	{
		Thread.sleep(2000);
		Assert.assertEquals("Tours Management",driver.getTitle());
		
	}


}
