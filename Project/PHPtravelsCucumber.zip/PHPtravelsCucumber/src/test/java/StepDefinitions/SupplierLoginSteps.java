package StepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import PageObjects.SupplierLoginObjects;
import io.cucumber.java.After;
import io.cucumber.java.en.*;

public class SupplierLoginSteps
{
	
	WebDriver driver=new ChromeDriver();
	SupplierLoginObjects supplierLogin=new SupplierLoginObjects(driver);
	
	
	@After
	public void TearDown()
	{
		
		driver.quit();
	}
	
	
	
	@Given("supplier is on login page")
	public void supplier_is_on_login_page() throws InterruptedException
	{
		driver.get("https://phptravels.net/supplier");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		System.out.println("The loaded site: "+driver.getCurrentUrl());
	}

	@When("^supplier enters email as (.*) and password as (.*)$")
	public void supplier_enters_username_and_password(String email, String password) throws InterruptedException
	{
		 supplierLogin.setEmail(email);
		 supplierLogin.setPassword(password);
		 Thread.sleep(2000);
	}

	@And("supplier click on login button")
	public void supplier_click_on_login_button() throws InterruptedException 
	{
	
		supplierLogin.clickLoginButton();
		Thread.sleep(2000);
		
	}

	@Then("supplier navigated to home page")
	public void supplier_navigated_to_home_page()
	{
		if(driver.getPageSource().contains("Dashboard"))
		{
			Assert.assertTrue(true);
		
		}
		else if(driver.getPageSource().contains("Supplier Login"))
		{
			Assert.assertTrue(true);
			
		}
	}

	
}
