package PageObjects;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AdminObjects 
{

	WebDriverWait wait;
	WebDriver driver;
	
	@FindBy(name="email")
	@CacheLookup
	WebElement txtEmail;
	
	@FindBy(name="password")
	@CacheLookup
	WebElement txtPassword;
	
	@FindBy(xpath="//span[text()='Login']")
	@CacheLookup
	WebElement btnLogin;
	
	////////////////////////////////////////////////////////
	
	@FindBy(xpath="//a[text()='Bookings']")
	@CacheLookup
	WebElement admin_bookings;
	
	@FindBy(xpath="(//select[@class='form-select status unpaid'])[1]//following::a[2]")
	@CacheLookup
	WebElement invoice;
	
	//////////////////////////////////////////////////////////
	
	
	@FindBy(xpath="//select[@class='form-select status cancelled']//following::button[2]")
	@CacheLookup
	WebElement delete_invoice;

	//select[@class='form-select status cancelled']//following::button[8]
	////////////////////////////////////
	
	@FindBy(xpath="//a[text()='Website']")
	@CacheLookup
	WebElement website;
	

	
	
	
	
	public AdminObjects(WebDriver newdriver)
	{
		this.driver=newdriver;
		PageFactory.initElements(newdriver,this);
		Duration timeout = Duration.ofMillis(1000); 
		wait= new WebDriverWait(driver, timeout);
	}
	
	public void setEmail(String email)
	{
		txtEmail.clear();
		txtEmail.sendKeys(email);
		
	}
	
	public void setPassword(String password)
	{
		txtPassword.clear();
		txtPassword.sendKeys(password);
		
	}
	
	public void clickLoginButton()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Login']")));
		btnLogin.click();
	}
	
	
	///////////////////////////////////////
	
	public void clickAdminBookings()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Bookings']")));
		admin_bookings.click();
	}
	
	
	public void setPaid() throws InterruptedException
	{
	
		Select confirm=new Select(driver.findElement(By.xpath("(//select[@class='form-select status unpaid'])[1]")));
		confirm.selectByVisibleText("Paid");
		JavascriptExecutor jse= (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();",invoice);
	}
	

	public void delete_invoice_button()
	{
		JavascriptExecutor jse= (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();",delete_invoice);
	}
	
	
	public void select_confirm()
	{
		Select confirm=new Select(driver.findElement(By.xpath("(//select[@class='form-select status pending'])[1]")));
		confirm.selectByVisibleText("Confirmed");
	}
	
	
	public void click_website()
	{
		JavascriptExecutor jse= (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();",website);
	}
	
	
	
	
	
	
	
	
}
