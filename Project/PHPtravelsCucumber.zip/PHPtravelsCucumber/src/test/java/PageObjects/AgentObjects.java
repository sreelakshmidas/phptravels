package PageObjects;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AgentObjects
{

	WebDriverWait wait;
	WebDriver driver;
	
	
	@FindBy(xpath="//input[@placeholder='Email']")
	@CacheLookup
	WebElement emailText;
	
	
	@FindBy(xpath="//input[@placeholder='Password']")
	@CacheLookup
	WebElement passText;
	
	
	@FindBy(xpath="//button[@type='submit']")
	@CacheLookup
	WebElement loginButton;
	
	/////////////////////////////////////////////////////////////
	
	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/bookings']//i")
	@CacheLookup
	WebElement my_booking;

	@FindBy(xpath="//a[@href='https://phptravels.net/account/add_funds']//i")
	@CacheLookup
	WebElement add_funds;

	@FindBy(xpath="//a[@href='https://phptravels.net/account/profile']//i")
	@CacheLookup
	WebElement my_profile;
	
	@FindBy(xpath=" //ul[@class='sidebar-menu list-items']//a[contains(.,'Logout')]")
	@CacheLookup
	WebElement btnLogout;
	

	
	///////////////////////////////////////////////////////////////
	//div[@class='logo']//following::img
	
	@FindBy(xpath="//div[@class='logo']//img[@alt='logo']")
	@CacheLookup
	WebElement home_logo;
	
	
	@FindBy(xpath="//a[@title='hotels']")
	@CacheLookup
	WebElement hotels_link;
	
	
	@FindBy(xpath="//a[@title='flights']")
	@CacheLookup
	WebElement flights_link;
	
	
	@FindBy(xpath="//a[@title='tours']")
	@CacheLookup
	WebElement tours_link;
	
	
	@FindBy(xpath="//a[@title='visa']")
	@CacheLookup
	WebElement visa_link;
	
	@FindBy(xpath="//a[@title='blog']")
	@CacheLookup
	WebElement blog_link;
	
	@FindBy(xpath="//a[@title='offers']")
	@CacheLookup
	WebElement offers_link;
	
	////////////////////
	

	@FindBy(xpath="//span[@title=' Search by City']")
	@CacheLookup
	WebElement city_search_bar;
	
	@FindBy(xpath="//input[@type='search']")
	@CacheLookup
	WebElement search_field;
	
	
	
	@FindBy(xpath="//*[@id='select2-hotels_city-results']/li/i[text()='Dubai,United Arab Emirates']")
	@CacheLookup
	WebElement select_city;
	
	
	@FindBy(xpath="//span[@class='select2-results']")
	List<WebElement> options;
	
	
	@FindBy(xpath="//button[@id='submit']")
	@CacheLookup
	WebElement search_icon;
	
	///////////////////////
	
	@FindBy(xpath="(//button[@id='currency'])[1] ")
	@CacheLookup
	WebElement select_USD;
	
	@FindBy(xpath="//*[@class='dropdown-menu show']/li/a[text()=' INR']")
	@CacheLookup 
	WebElement select_INR;
	
	
	
	
	public AgentObjects(WebDriver newdriver)
	{
		this.driver=newdriver;
		PageFactory.initElements(newdriver,this);
		Duration timeout = Duration.ofMillis(10000); 
		wait= new WebDriverWait(driver, timeout);
	}
	
	
	public void setEmailField(String email)
	{
		emailText.clear();
		emailText.sendKeys(email);
		
	}
	
	public void setPasswordField(String password)
	{
		passText.clear();
		passText.sendKeys(password);
		
	}
	
	public void clickLoginButtonAgent()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@type='submit']")));
		loginButton.click();
	}
	
	
	
	////////////////////////////////////////////////////////////////////////
	
	public void clickBooking()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href='https://phptravels.net/account/bookings']//i")));
		my_booking.click();
	}

	public void clickAddFunds()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href='https://phptravels.net/account/add_funds']//i")));
		add_funds.click();
	}

	public void clickMyProfile()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href='https://phptravels.net/account/profile']//i")));
		my_profile.click();
	}

	public void clickLogout()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@class='sidebar-menu list-items']//a[contains(.,'Logout')]")));
		btnLogout.click();
	}
	
	
	/////////////////////////////////////////////////////////////////////////
	
	
	public void click_HomeLogo()
	{
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='logo']//img[@alt='logo']")));
		home_logo.click();

		
		
	}
	
	public void click_Hotel() throws InterruptedException
	{
		
		Thread.sleep(3000);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[text()='Hotels']")));
		hotels_link.click();
		
		
	}
	
	public void click_Flights()
	{
		JavascriptExecutor jse= (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();",flights_link);
		
	}
	
	public void click_Tours()
	{
		JavascriptExecutor jse= (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();",tours_link);
		
	}
	
	public void click_Visa()
	{
		JavascriptExecutor jse= (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();",visa_link);
		
	}
	
	public void click_Blog()
	{
		JavascriptExecutor jse= (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();",blog_link);
		
	}
	
	public void click_Offers()
	{
		JavascriptExecutor jse= (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();",offers_link);
		
	}
	
	///////////////////////////////////////////////////////
	
	
	public void search_hotel(String city) throws InterruptedException
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@title=' Search by City']")));
		city_search_bar.click();
		
		Thread.sleep(3000);
		
		
		search_field.clear();
		search_field.sendKeys(city);
		
		Thread.sleep(3000);
		
		for(WebElement option : options)
		{
			if(option.getText().equalsIgnoreCase("Dubai,United Arab Emirates"))
			{
				option.click();
				Thread.sleep(2000);
				break;
			}
		}
		
		Thread.sleep(3000);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='submit']")));
		search_icon.click();
		
		
		
	}
	
	
	public void select_currency() throws InterruptedException
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[@id='currency'])[1] ")));
		select_USD.click();
		
		Thread.sleep(2000);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='dropdown-menu show']/li/a[text()=' INR']")));
		select_INR.click();
		
		Thread.sleep(2000);
		
	}
	
	
	
}
