package PageObjects;

import java.time.Duration;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CustomerObjects 
{
	WebDriverWait wait;
	WebDriver driver;


	@FindBy(xpath="//a[@href='https://phptravels.net/account/bookings']//i")
	@CacheLookup
	WebElement my_booking;

	@FindBy(xpath="//a[@href='https://phptravels.net/account/add_funds']//i")
	@CacheLookup
	WebElement add_funds;

	@FindBy(xpath="//a[@href='https://phptravels.net/account/profile']//i")
	@CacheLookup
	WebElement my_profile;
	
	@FindBy(xpath=" //ul[@class='sidebar-menu list-items']//a[contains(.,'Logout')]")
	@CacheLookup
	WebElement btnLogout;

	@FindBy(xpath="//input[@value='paypal']")
	@CacheLookup
	WebElement radio_paypal;


	@FindBy(xpath="//button[@type='submit']")
	@CacheLookup
	WebElement button_paynow;


	@FindBy(xpath="//div[@class='btn-front']")
	@CacheLookup
	WebElement backto_invoice;

	@FindBy(xpath="//a[@class='yes']")
	@CacheLookup
	WebElement click_yes;

	@FindBy(xpath="//a[text()=' View Voucher'][1]")
	@CacheLookup
	WebElement view_voucher;

	@FindBy(xpath="//input[@name='address1']")
	@CacheLookup
	WebElement input_address;

	@FindBy(xpath="//button[text()='Update Profile']")
	@CacheLookup
	WebElement update_profile;


	@FindBy(xpath="//div[@class='alert alert-success']")
	@CacheLookup
	WebElement update_profile_text;






	public CustomerObjects(WebDriver newdriver)
	{
		this.driver=newdriver;
		PageFactory.initElements(newdriver,this);
		Duration timeout = Duration.ofMillis(1000); 
		wait= new WebDriverWait(driver, timeout);
	}

	
	
	public void clickBooking()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href='https://phptravels.net/account/bookings']//i")));
		my_booking.click();
	}

	public void clickAddFunds()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href='https://phptravels.net/account/add_funds']//i")));
		add_funds.click();
	}

	public void clickMyProfile()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href='https://phptravels.net/account/profile']//i")));
		my_profile.click();
	}

	public void clickLogout()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@class='sidebar-menu list-items']//a[contains(.,'Logout')]")));
		btnLogout.click();
	}
	
	public void clickPayPal()
	{
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='paypal']")));
		JavascriptExecutor jse= (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();",radio_paypal);
		//radio_paypal.click();
	}

	public void clickPayNow()
	{
		//	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@type='submit']")));
		//	button_paynow.click();
		JavascriptExecutor jse= (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();",button_paynow);
	}

	public void clickBackToInvoice()
	{
		//	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='btn-front']")));
		//	backto_invoice.click();
		JavascriptExecutor jse= (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();",backto_invoice);
	}

	public void clickYes()
	{
		//	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='yes']")));
		//	click_yes.click();
		JavascriptExecutor jse= (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();",click_yes);
	}

	public void clickViewVoucher()
	{
		JavascriptExecutor jse= (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();",view_voucher);
	}

	public void setAddress(String address)
	{
		input_address.clear();
		input_address.sendKeys(address);

	}

	public void clickUpdateProfile()
	{
		JavascriptExecutor jse= (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();",update_profile);
	}

	public boolean getUpdateProfileText()
	{
		boolean updateText=update_profile_text.getText().contains("Profile updated successfully");
		return updateText;

	}

}	


