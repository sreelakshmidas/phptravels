package PageObjects;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AdminLoginObjects 
{

	
	WebDriverWait wait;
	WebDriver driver;
	
	
	@FindBy(name="email")
	@CacheLookup
	WebElement txtEmail;
	
	@FindBy(name="password")
	@CacheLookup
	WebElement txtPassword;
	
	@FindBy(xpath="//span[text()='Login']")
	@CacheLookup
	WebElement btnLogin;
	
	
	public AdminLoginObjects(WebDriver newdriver)
	{
		this.driver=newdriver;
		PageFactory.initElements(newdriver,this);
		Duration timeout = Duration.ofMillis(1000); 
		wait= new WebDriverWait(driver, timeout);
	}
	
	public void setEmail(String email)
	{
		txtEmail.clear();
		txtEmail.sendKeys(email);
		
	}
	
	public void setPassword(String password)
	{
		txtPassword.clear();
		txtPassword.sendKeys(password);
		
	}
	
	public void clickLoginButton()
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Login']")));
		btnLogin.click();
	}
	
}
